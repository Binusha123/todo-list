const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");
const { format } = require("date-fns"); // FIXED

const app = express();
app.use(express.json());

const dbPath = path.join(__dirname, "todoApplication.db");
let db = null;

// Initialize DB
const initializeDBAndServer = async () => {
  try {
    db = await open({
      filename: dbPath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () => {
      console.log("Server Running at http://localhost:3000/");
    });
  } catch (e) {
    console.log(`DB Error: ${e.message}`);
  }
};

initializeDBAndServer();

// VALIDATION FUNCTIONS
const isValidStatus = (val) =>
  ["TO DO", "IN PROGRESS", "DONE"].includes(val);

const isValidPriority = (val) =>
  ["HIGH", "MEDIUM", "LOW"].includes(val);

const isValidCategory = (val) =>
  ["WORK", "HOME", "LEARNING"].includes(val);

const isValidDate = (val) => {
  try {
    const f = format(new Date(val), "yyyy-MM-dd");
    return f !== "Invalid Date";
  } catch {
    return false;
  }
};

// ----------------------------------------------------
// API 1: GET TODOS with Filters
// ----------------------------------------------------
app.get("/todos/", async (request, response) => {
  const { status, priority, category, search_q = "" } = request.query;

  if (status !== undefined && !isValidStatus(status)) {
    response.status(400).send("Invalid Todo Status");
    return;
  }
  if (priority !== undefined && !isValidPriority(priority)) {
    response.status(400).send("Invalid Todo Priority");
    return;
  }
  if (category !== undefined && !isValidCategory(category)) {
    response.status(400).send("Invalid Todo Category");
    return;
  }

  const query = `SELECT *
FROM todo
WHERE todo LIKE '%${search_q}%'
  AND ('${status}' = '' OR status = '${status}')
  AND ('${priority}' = '' OR priority = '${priority}')
  AND ('${category}' = '' OR category = '${category}');
`;

  const result = await db.all(query);
  response.send(result);
});

// ----------------------------------------------------
// API 2: GET Todo by ID
// ----------------------------------------------------
app.get("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;

  const query = `SELECT * FROM todo WHERE id=${todoId};`;
  const result = await db.get(query);
  response.send(result);
});

// ----------------------------------------------------
// API 3: POST Add Todo
// ----------------------------------------------------
app.post("/todos/", async (request, response) => {
  const { id, todo, priority, status, category, due_date } = request.body;

  if (!isValidStatus(status)) {
    response.status(400).send("Invalid Todo Status");
    return;
  }
  if (!isValidPriority(priority)) {
    response.status(400).send("Invalid Todo Priority");
    return;
  }
  if (!isValidCategory(category)) {
    response.status(400).send("Invalid Todo Category");
    return;
  }
  if (!isValidDate(due_date)) {
    response.status(400).send("Invalid Due Date");
    return;
  }

  const formattedDate = format(new Date(due_date), "yyyy-MM-dd");

  const insertQuery = `
        INSERT INTO todo (id, todo, priority, status, category, due_date)
        VALUES (${id}, '${todo}', '${priority}', '${status}', '${category}', '${formattedDate}');
    `;

  await db.run(insertQuery);
  response.send("Todo Successfully Added");
});

// ----------------------------------------------------
// API 4: PUT Update Todo
// ----------------------------------------------------
app.put("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;
  const { status, priority, todo, category, due_date } = request.body;

  let updateField = "";
  let query = "";

  if (status !== undefined) {
    if (!isValidStatus(status)) {
      response.status(400).send("Invalid Todo Status");
      return;
    }
    updateField = "Status";
    query = `UPDATE todo SET status='${status}' WHERE id=${todoId};`;
  } else if (priority !== undefined) {
    if (!isValidPriority(priority)) {
      response.status(400).send("Invalid Todo Priority");
      return;
    }
    updateField = "Priority";
    query = `UPDATE todo SET priority='${priority}' WHERE id=${todoId};`;
  } else if (todo !== undefined) {
    updateField = "Todo";
    query = `UPDATE todo SET todo='${todo}' WHERE id=${todoId};`;
  } else if (category !== undefined) {
    if (!isValidCategory(category)) {
      response.status(400).send("Invalid Todo Category");
      return;
    }
    updateField = "Category";
    query = `UPDATE todo SET category='${category}' WHERE id=${todoId};`;
  } else if (due_date !== undefined) {
    if (!isValidDate(due_date)) {
      response.status(400).send("Invalid Due Date");
      return;
    }
    const formattedDate = format(new Date(due_date), "yyyy-MM-dd");
    updateField = "Due Date";
    query = `UPDATE todo SET due_date='${formattedDate}' WHERE id=${todoId};`;
  }

  await db.run(query);
  response.send(`${updateField} Updated`);
});

// ----------------------------------------------------
// API 5: DELETE Todo
// ----------------------------------------------------
app.delete("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;

  const deleteQuery = `DELETE FROM todo WHERE id=${todoId};`;
  await db.run(deleteQuery);

  response.send("Todo Deleted");
});
module.exports = app;